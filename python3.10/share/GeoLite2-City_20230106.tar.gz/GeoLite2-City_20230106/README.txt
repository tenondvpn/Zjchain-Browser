Latitude and longitude are not precise and should not be used to identify a particular street address or household.
