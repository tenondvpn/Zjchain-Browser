livizjs
=======

Interactive Graphviz in javascript

How to build
-------
Sorry! Build steps are not fully automated.
Please do the following preparation.

1. Install Emscripten
2. Backup original Emscripten if you need.
3. Replace src/shell.js and src/library.js in Emscripten with modified files. Modified files are in the source tree.