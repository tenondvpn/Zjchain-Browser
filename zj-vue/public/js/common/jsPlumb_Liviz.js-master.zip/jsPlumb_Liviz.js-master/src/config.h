#define GVPLUGIN_CONFIG_FILE "config6"
#define GVPLUGIN_VERSION 6
#define PACKAGE "graphviz"
#define PACKAGE_BUGREPORT "http://www.graphviz.org/"
#define PACKAGE_NAME "graphviz"
#define PACKAGE_STRING "graphviz 2.28.0"
#define PACKAGE_TARNAME "graphviz"
#define PACKAGE_URL ""
#define PACKAGE_VERSION "2.28.0"
#define VERSION "2.28.0"

#define HAVE_BOOL 1
#undef ENABLE_LTDL

#undef HAVE_EXPAT
#undef HAVE_EXPAT_H

#define HAVE_ERRNO_H 1

#define DEFAULT_DPI 96

#define HAVE_STRDUP 1

#define SFDP 1

//#define HAVE_GTS 1

//#define HAVE_TRIANGLE 1

#define HAVE_INTPTR_T 1

#define HAVE_STDINT_H 1
